/*
 * eBot_MCU_Predef.cpp
 *
 *  Created on: 11-Jan-2021
 *      Author: TAs of CS 684 Spring 2020
 */


//---------------------------------- INCLUDES ----------------------------------

#include "eBot_MCU_Predef.h"


//---------------------------------- FUNCTIONS ----------------------------------

/**
 * @brief      Function to configure pins of micro-controller to which pins of L293D Motor Driver IC is connected
 */
void motors_pin_config(void)
{
	motors_dir_ddr_reg = ;			// motor pins as output
	motors_dir_port_reg = ;		// stop motors initially
}


/**
 * @brief      Function to configure left and right channel pins of the L293D Motor Driver IC for PWM
 */
void pwm_pin_config(void)
{
	motors_pwm_ddr_reg = ;	// left and right channel pin as output
	motors_pwm_port_reg = ;	// enable left and right channel
}


/**
 * @brief      Function to initialize Timer in Phase Correct PWM mode for speed control of motors of the robot
 */
void timer_pwm_init(void)
{
	// Make values in both Output Compare Registers as 0
	OCRAH_reg = ;
	OCRAL_reg = ;
	OCRBH_reg = ;
	OCRBL_reg = ;

	// Clear on Compare
	TCCRA_reg = ;
	TCCRA_reg = ;

	// Configure for Phase Correct PWM
	TCCRA_reg = ;
	TCCRA_reg = ;
	TCCRB_reg = ;
	TCCRB_reg = ;

	// Set Prescalar to 64
	TCCRB_reg = ;
	TCCRB_reg = ;
}


/**
 * @brief      Function to make the robot move forward.
 */
void forward(void)
{
	motors_dir_port_reg =  ;	// Make LF, LB, RF, RB LOW
	motors_dir_port_reg =  ;	// Make LF and RF HIGH
}


/**
 * @brief      Function to control the speed of both the motors of robot
 *
 * @param[in]  left_motor_speed   Left motor speed 0 to 255
 * @param[in]  right_motor_speed  Right motor speed 0 to 255
 */
void velocity(unsigned char left_motor_speed, unsigned char right_motor_speed)
{
	OCRAL_reg = ;
	OCRBL_reg = ;
}


/**
 * @brief      Initializes the setup by configuring all the required devices
 */
int init_setup(void)
{
	// Initialize motor pins
	motors_pin_config();

	// Initialize PWM pins as output
	pwm_pin_config();

	// Initialize Timer in Phase Correct PWM mode
	timer_pwm_init();

	return 1;
}

